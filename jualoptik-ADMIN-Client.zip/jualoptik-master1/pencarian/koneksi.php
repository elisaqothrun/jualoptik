<?php
define('HOST','localhost');
define('USER','root');
define('PASS','');
define('DB1', 'kos');
 
// Buat Koneksinya
$kos = new mysqli('localhost', 'root', '', 'kos');
?>