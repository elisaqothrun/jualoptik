<?php
session_start();
include 'koneksi.php';
?>
 <!DOCTYPE html>
<html>
<head>
	<title>Kategori Barang</title>
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
</head>
<body>

	<?php include "menu.php"; ?>


  <!--Konten-->
  <section class="konten">
    <div class=" bg-primary jumbotron jumbotron-fluid">
    <div class="container">
      <h1 align="center" style="font-family: Calibri; color: white;">Kategori Barang</h1>

      <div class="row-md-6">

        <?php 
        // $idk = $_GET["id"];
        $ambil = $koneksi->query("SELECT * FROM barang inner join kategori on barang.ID_KATEGORI = kategori.ID_KATEGORI ORDER BY barang.ID_KATEGORI ASC"); 
          while ($perbarang = $ambil->fetch_assoc() ){ ?>



        <div class="col-md-3">
          <div class="thumbnail bg-info">
            <img src="foto_produk/<?php echo $perbarang['GAMBAR_BARANG']; ?>" alt="" width="250px" length="250px">
            <!--<?php echo '<img src="data:image/jpeg;base64,'.base64_encode( $perbarang['GAMBAR_BARANG'] ).'" width="250px" length="250px"/>'; ?> -->
           <!-- <img src="foto_produk/<?php #echo data:image/jpeg;base64, '.base64_encode($perbarang[GAMBAR_BARANG]) ?>" alt=""> -->
            <div class="caption bg-dark">
              <h3 class="text-light"><?php echo $perbarang['KATEGORI'];?></h3>
              <a href="barang.php?id=<?php echo $perbarang['ID_KATEGORI'];?> " class="btn-danger btn">Selengkapnya</a>

            </div>
          </div>
        </div>
        <?php } ?>
      </div>
    </div>
  </div>
  </section>

</body>
</html>