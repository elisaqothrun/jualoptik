<?php session_start();
include 'koneksi.php';


$ID_BARANG = $_GET["id"];
//$_SESSION["ID_BARANG"]= $ID_BARANG;
$ambil=$koneksi->query("SELECT * FROM barang WHERE ID_BARANG='$ID_BARANG'");
$detail= $ambil->fetch_assoc();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Detail Barang</title>
	<link type="text/css" rel="stylesheet" href="assets/css/bootstrap.min.css ">
</head>
<body>

<?php include "menu.php"; ?>

<!--Konten-->
	<section class="kontent">
		<div class="bg-primary jumbotron jumbotron-fluid">
		<div class="container">
			<div class="col">
				<div class="col-md-6">
					<!-- <?php echo '<img src="data:image/jpeg;base64,'.base64_encode($detail['GAMBAR_BARANG'] ).'" alt="" class="img-responsive" length="100px" width="100px"/>'; ?>
				-->
					<img src="foto_produk/<?php echo $detail["GAMBAR_BARANG"];?>" alt="" class="img-responsive">
				</div>
			<div class="col-md-6">
				<h2 class="text-light">Nama barang: <?php echo $detail ["NAMA_BARANG"] ?></h2>
				<h3 class="text-light">Harga: Rp.<?php echo number_format($detail ["HARGA_BARANG"]) ?></h4>
				<h2 class="text-light">Stok :<?php echo $detail ["STOK_BARANG"] ?></h2>
				<form method="post">
					<div class="form-group">
						<div class="input-group">
							<input type="number" min="1" class="form-control" name="jumlah"  max="<?php echo $detail['STOK_BARANG'];  ?>" placeholder="Masukkan jumlah pembelian">
					</div>
					</div>
				</div>
				<div class="input-group-btn">
					<button class="btn btn-warning" name="beli">Masukan Keranjang</button>
				</div>
				</form>
				<?php 
				//jika ada tombol beli
				if (isset($_POST["beli"])){
					//mendpatkan jumlah yang diinputkan dalam form
					//$array = array[$ID_BARANG,$jumlah];
					$jumlah=$_POST["jumlah"];
					//masukan ke keranjang belanja
					//$a = $_SESSION["keranjang"];
					//$b = $_SESSION["ID_BARANG"];

					//$array = array[$ID_BARANG,$jumlah];
					$_SESSION["keranjang"][$ID_BARANG] = $jumlah;

					echo "<script>alert('produk telah masuk ke keranjang');</script>";
					echo "<script>location='keranjang.php';</script>";
				}
				?>
				<div class="text-light">
				<h2>Deskripsi barang :<?php echo $detail ["DESKRIPSI_BARANG"] ?></h2></div>
			</div>
		</div>
		</div></div>
	</section>

