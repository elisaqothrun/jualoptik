
 <!-- Navbar -->
          <link rel="stylesheet" href="assets/css/bootstrap.css">
     <nav class="navbar navbar-expand-lg navbar-light bg-dark fixed-top" id="mainNav">
    <div class="container">

      <ul class="nav navbar-nav navbar-left" style="font-size: 20px;">

          <li><a href="index.php">Optik Surya</li>
          <li><a href="kategori.php">Kategori</li>
          <li><a href="daftar.php">Daftar</li>
          <!-- <li><a href="keranjang.php">Keranjang</li> -->

            <!--jk sudah login(ada session pembeli)-->
            <!-- <?php #if (isset($_SESSION["pembeli"])): ?>
            <li><a href="logout.php">Logout</a></li> -->
             <!--jika belum login belum ada session pembeli--> 
            <!--<?php #else : ?>
              <li><a href="login.php">Login</a></li>
            <?php #endif ?>
          -->
      </ul>
      
      <ul class="nav navbar-nav navbar-right" style="font-size: 20px;">
            <li><a href="keranjang.php">Keranjang</li>
            <!--jk sudah login(ada session pembeli)-->
            <?php if (isset($_SESSION["pembeli"])): ?>
            <li><a href="logout.php">Logout</a></li>
             <!--jika belum login belum ada session pembeli--> 
            <?php else : ?>
              <li><a href="login.php">Login</a></li>
            <?php endif ?>
      </ul>
     
     
      <form action="pencarian.php" method="get" class="navbar-form navbar-right" style="font-size: 40px;">
        <input type="text" class="form-control" name="keyword" placeholder="Cari produk">
        <button class="btn btn-primary">Cari</button>
      </form>
    <!--<form action="datacoba.php" method="post" class="navbar-form navbar-right">
            <input type="text" name="s_keyword" id="s_keyword" class="form-control">
            <button id="search" name="search" class="btn btn-primary"><i class="fa fa-search"></i> Cari</button>     
    </form>-->
 
<div class="data"></div>
    </div>
  </nav>