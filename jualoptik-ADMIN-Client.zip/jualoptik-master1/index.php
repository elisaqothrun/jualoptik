<?php 
session_start();
include 'koneksi.php';
?>
 <!DOCTYPE html>
<html>
<head>
	<title>Optik Surya</title>
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="assets/css/font-awesome.css">
</head>
</head>
<body>

<?php include "menu.php"; ?>

	<!--Konten-->
	<section class="konten">
		<div class="bg-primary jumbotron jumbotron-fluid">
			<h1 align="center" class="text-light">Rekomendasi Produk</h1>

			<div class="container">

				<?php $ambil = $koneksi->query("SELECT * FROM barang"); ?>
				<?php while ($perbarang = $ambil->fetch_assoc() ){ ?>
					

				<div class="col-md-4">
					<div class="thumbnail">
						<!-- Code num 32 is to convert from BLOB Binary to JPG -->
						<img src="foto_produk/<?php echo $perbarang['GAMBAR_BARANG']; ?>" alt="" width="200px" length="200px">
						<!-- <?php echo '<img src="data:image/jpeg;base64,'.base64_encode( $perbarang['GAMBAR_BARANG'] ).'"/>'; ?> -->
						<div class="caption bg-danger">
							<h3 class="text-light"><?php echo $perbarang['NAMA_BARANG'];?></h3>
							<h5 class="text-light">Rp. <?php echo number_format($perbarang['HARGA_BARANG']);?></h5>
							<h6 class="text-light">Stok : <?php echo $perbarang['STOK_BARANG']; ?></h6>
								<a href="beli.php?id=<?php echo $perbarang['ID_BARANG']; ?>" class="btn btn-info">Beli</a>
								<a href="detail.php?id=<?php echo $perbarang['ID_BARANG']; ?>" class="btn btn-warning">Detail</a>
							
						</div>
					</div>
				</div>
				<?php } ?>
			</div>
		</div>
	</section>

</body>
</html>