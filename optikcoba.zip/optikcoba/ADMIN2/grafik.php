<div class="row">
	<div class="col-lg-12">
		<h1>Penjualan <small>Grafik Penjualan</small></h1>
		<ol class="breadcrumb">
		<li <a href=""><i class="fa fa-dashboard"></i></a></li>
		<li <a href="">Grafik</a></li>
		<li class="active">Grafik Penjualan</li>
		</ol>
	</div>
</div>
<div class="row">
	<div class="col-lg-12">
		<div id="data"></div>
	</div>
</div>
<?php 
$semuadata=array();
$tanggal=array();
// $tgl_mulai="-";
// $tgl_selesai="-";
// $penjualan=

//if (isset($_POST["kirim"])) 
	$ambil= $koneksi->query("SELECT * FROM pemesanan pm LEFT JOIN pembeli pl ON pm.NIK=pl.NIK WHERE TGL_PEMESANAN ");
	while($pecah = $ambil -> fetch_object())
	{
        $tanggal[]=intval($pecah->TGL_PEMESANAN);
		$semuadata[]=$pecah;
	}
print_r(json_encode($semuadata));
?>

<script src="assets/highcharts/highcharts.js"></script>
<script src="assets/highcharts/exporting.js"></script>
<!-- //<script src="https://code.highcharts.com/modules/export-data.js"></script>
<script src="https://code.highcharts.com/modules/accessibility.js"></script> -->
<script type="text/javascript">
	Highcharts.chart('data', {
    chart: {
        type: 'area'
    },
    title: {
        text: 'Data Penjualan'
    },
    subtitle: {
        text: 'Source: Optik Surya'
    },
    xAxis: {
        categories: <?=json_encode($semuadata);?>,
        tickmarkPlacement: 'on',
        title: {
            enabled: false
        }
    },
    yAxis: {
        title: {
            text: 'Penjualan tanggal'
        },
        labels: {
            formatter: function () {
                return this.value;
            }
        }
    },
    tooltip: {
        split: true,
        valueSuffix: ''
    },
    plotOptions: {
        area: {
            stacking: 'normal',
            lineColor: '#666666',
            lineWidth: 1,
            marker: {
                lineWidth: 1,
                lineColor: '#666666'
            }
        }
    },
    series: [{
        name: 'tanggal',
        data:<?=json_encode($tanggal);?>
    }]
});
</script>
